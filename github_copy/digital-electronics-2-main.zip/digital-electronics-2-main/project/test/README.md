https://www.best-microcontroller-projects.com/arduino-joystick.html
https://www.youtube.com/watch?v=v4BbSzJ-hz4
http://www.energiazero.org/arduino_sensori/joystick_module.pdf





lcd
j1 1-4  -   data bity : D4-D7
j1 5    -   gnd
j1 6    -   +5V
j2 1    -   B0(D8)
j2 2    -   GND
j2 3    -   B1(D9)
