var searchData=
[
  ['assembly_20functions_0',['Assembly functions',['../group__fryza__asm.html',1,'']]]
];
