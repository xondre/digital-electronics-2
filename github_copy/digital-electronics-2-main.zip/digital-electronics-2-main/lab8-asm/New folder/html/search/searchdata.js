var indexSectionsWithContent =
{
  0: "alm",
  1: "lm",
  2: "a",
  3: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "groups",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Modules",
  3: "Pages"
};

